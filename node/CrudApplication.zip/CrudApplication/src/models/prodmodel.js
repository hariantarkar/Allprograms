
const { promiseImpl } = require("ejs");
let db=require("../../db.js");

exports.saveProd=(name,category,price,quantity)=>{
    return new Promise((resolve,reject)=>{
        db.query("insert into Product values('0',?,?,?,?)",[name,category,price,quantity],(err,result)=>{
            if(err)
            {
                console.log("Product  values not save..");
                reject(err);
            }
            else{
                console.log(result);
                resolve("Product values save successfully...");

            }
        });
    });
}
exports.getAllProduct=()=>{
    return new Promise((resolve,reject)=>{
        db.query("select *from Product",(err,result)=>{
            if(err)
            {
                reject(err);
            }
            else{
                resolve(result);
            }
        });

    });
}
exports.delProdById = (Pid) =>{
     return new Promise((resolve,reject)=>{
        db.query("delete from Product where Pid=?",[Pid],(err,result)=>{
            if(err)
            {
                reject(err);
            }
            else{
                resolve(result);
            }
        });
    })
};
// exports.finalUpdateProduct=(Pid,name,category,price,quantity)=>{
//     console.log("update model hits.....");
//     return new Promise((resolve,reject)=>{
//         db.query("update Product set name=?,category=?,price=?,quantity=? where Pid=?",[name,category,price,quantity,Pid],(err,result)=>{
//             if(err)
//             {
//                 reject(err);
//             }
//             else{
//                 resolve("Update Success");
//             }
//         });
//     });
// }


exports.finalUpdateProduct = (Pid, name, category, price, quantity) => {
    console.log("Update model hits.....");
    console.log(Pid+" "+name+" "+category, price, quantity)
    return new Promise((resolve, reject) => {
        db.query(
            "UPDATE Product SET name = ?, category = ?, price = ?, quantity = ? WHERE Pid = ?",
            [name, category, price, quantity, Pid],
            (err, result) => {
                if (err) {
                    console.error("Error while updating:", err);
                    reject(err);
                } else {
                    resolve("Update Success");
                }
            }
        );
    });
};
exports.getProdByName = (name) => {
   
    return new Promise((resolve, reject) => {
        db.query("SELECT * FROM Product WHERE name LIKE ?", [`%${name}%`], (err, result) => {
            if (err) {
                reject(err);
            } else {
               
                resolve(result);
            }
        });
    });
};

