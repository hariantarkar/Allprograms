let express = require("express");
let conn = require("../db.js");
let router = require("./routes/router");
let path = require("path");
let bodyParser = require("body-parser");
let app = express();
app.set("view engine", "ejs");
app.set("views", path.join(__dirname,"..", "views"));
app.use(express.static(path.join(__dirname,"..","public")));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

app.use("/", router);

module.exports = app;
