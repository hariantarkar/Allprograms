
let prodmodel=require("../models/prodmodel.js");
exports.saveProd=((req,res)=>{
    let {name,category,price,quantity}=req.body;
    let promise=prodmodel.saveProd(name,category,price,quantity);
    promise.then((result)=>{
        if(result.affectedRows!=0)
        {
            res.render("addProduct.ejs",{msg:result});
        }
        else
        {
            res.render("addProduct.ejs",{msg:err});
        }
    }).catch((err) => {
            res.render("addProduct.ejs",{msg:err});
       
    });
});

exports.homePage=(req,res)=>{
    res.render("home");
}
exports.addProductPage=(req,res)=>{
    res.render("addProduct",{msg:""});

};
exports.getAllProduct=(req,res)=>{
    let p=prodmodel.getAllProduct();
        p.then((result)=>{
            res.render("ViewProducts.ejs",{ProdList:result});

        }).catch((err)=>{
            res.send(err);
        });
}

exports.delProd = (req, res) => {
    let Pid = parseInt(req.query.Pid);
    let promise = prodmodel.delProdById(Pid);

    promise.then((result) => {
        let p = prodmodel.getAllProduct();
        p.then((result) => {
            res.render("viewProducts.ejs", { ProdList: result });
        }).catch((err) => {
            res.send(err);
        });
    }).catch((err) => {
        res.send(err);
    });
};

exports.updProd=(req,res)=>{
    let { Pid, name, category, price, quantity } = req.query;
    res.render("updateProd.ejs", {Pid,name,category,price, quantity });
};


exports.FinalUpdateProd=(req,res)=>{
     console.log("update ctrl hits.....");
    let {Pid,name,category,price,quantity}=req.body;
    let promise=prodmodel.finalUpdateProduct(Pid,name,category,price,quantity);
    promise.then((result)=>{
        let p=prodmodel.getAllProduct();
        p.then((result)=>{
            res.render("ViewProducts.ejs",{ProdList:result});
        })
    });
        promise.catch((err)=>{
            res.send("Product not Update");
        });
   
}
exports.searchProduct=((req,res)=>{
    let name=req.query.name;
    let promise=prodmodel.getProdByName(name);
    promise.then((result)=>{
        res.json(result);
    }).catch((err)=>{
        res.send("something went wrong");
    })
});

