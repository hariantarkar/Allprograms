let express=require("express");
let prodctrl=require("../controllers/prodctrl.js");
const { route } = require("../app.js");

let router=express.Router();
 router.get("/",prodctrl.homePage);
 router.get("/addProduct",prodctrl.addProductPage);
 router.post("/addProduct",prodctrl.saveProd);
 router.get("/ViewProducts",prodctrl.getAllProduct);
 router.get("/delProd",prodctrl.delProd);
 router.get("/updateProd", prodctrl.updProd); 
 router.post("/updateProd", prodctrl.FinalUpdateProd); 
router.get("/searchProdByName",prodctrl.searchProduct);

module.exports=router;
